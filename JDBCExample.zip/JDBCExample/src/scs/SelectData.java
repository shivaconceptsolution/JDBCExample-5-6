package scs;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class SelectData {

	public static void main(String[] args) throws ClassNotFoundException, SQLException {
		 Class.forName("com.mysql.jdbc.Driver");
		 Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/java56db","root","");
		 Statement st = conn.createStatement();
		 ResultSet res = st.executeQuery("select * from dept");
		 while(res.next())
		 {
			 System.out.println(res.getInt(1)+" "+ res.getString(2));
		 }
		 res.close();
	}

}
