package scs;
import java.sql.*;
import java.util.Scanner;
public class InsertData {

	public static void main(String args[]) throws ClassNotFoundException, SQLException
	{
		int did;
		String dname;
		Scanner sc = new Scanner(System.in);
		System.out.println("Data Deptid");
		did = sc.nextInt();
		System.out.println("Data Deptname");
		dname = sc.next();
		
	   Class.forName("com.mysql.jdbc.Driver");
	   Connection conn = DriverManager.getConnection("jdbc:mysql://localhost:3306/java56db","root","");
	   Statement st = conn.createStatement();
	   int x = st.executeUpdate("insert into dept(deptid,deptname) values('"+did+"','"+dname+"')");
	   if(x!=0)
	   {
		   System.out.println("Data Inserted Successfully");
	   }
	   else
	   {
		   System.out.println("Data not Inserted Successfully");
	   }
	   
		
	}
}
